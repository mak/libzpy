

class storageException(Exception):
  pass

